#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

char artigo[5][10] = {"o","um", "algum", "todo", "qualquer"};
char substantivo[5][10] = {"menino","homem","cachorro","carro","gato"};
char verbo[5][10] = {"passou","pulou","correu","saltos","andou"};
char preposicao[5][10] = {"sobre","sob","antes","ate","com"};

void gerador();

void gerador(char v[100])
{
	int i;
	
	srand(time(NULL));
	
	for(i=0; i<20; i++)
	{
		printf("%s %s %s %s %s %s\n\n",artigo[rand()%5], substantivo[rand()%5], verbo[rand()%5], preposicao[rand()%5], artigo[rand()%5], substantivo[rand()%5]);

		if(i==19)
		{
			strcat(v, artigo[rand()%5]); strcat(v, " "); 

			strcat(v, substantivo[rand()%5]); strcat(v, " "); 
			
			strcat(v, verbo[rand()%5]); strcat(v, " "); 
			
			strcat(v, preposicao[rand()%5]); strcat(v, " "); 
			
			strcat(v, artigo[rand()%5]); strcat(v, " "); 
			
			strcat(v, substantivo[rand()%5]); strcat(v, "."); 
			break;
		}
	}
    
    v[0] = toupper(v[0]);
}


int main()
{
	char palavra[100];
    gerador(palavra);
	printf("%s\n", palavra);
	
	return 0;
}
