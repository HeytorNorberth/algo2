#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct 
{
    int chave;
    char nome[30], endereco[50], telefone[14];
} Alunos;

void gerarDados(Alunos *v, int n, int ordemChave);

void troca (Alunos *v1, Alunos *v2);

void Imprimir(Alunos *v, int n);

int main()
{
    srand(time(NULL));
    
    int n, ordem, i;
    
    scanf("%d", &n);
    
    while(1)
    {
        scanf("%d", &ordem);
        
        if(ordem == 3) break;
        
        Alunos vetor[n];
         
        gerarDados(vetor, n, ordem);
        Imprimir(vetor, n);
    }
   
    return 0;
}

void gerarDados(Alunos *v, int n, int ordemChave)
{
    int i, index;
    
    if(ordemChave == 0 || ordemChave == 1)
    {
        for(i = 0; i < n; i++)
        {
            v[i].chave = i+1;
        }
    }
    else if(ordemChave == 2)
    {
        int j;
        for(i = n-1, j = 0; i >= 0; i--, j++){
            v[j].chave = i+1;
        }
    }
    if(ordemChave == 1)
    {
        int j;
        for(i = 0, j = n*n; j > 0; i++, j--)
        {
            if(i = n)
            {
                i = 0;
                index = rand() % n;
                troca(&v[i], &v[index]);
            }
        }
    }
}

void troca(Alunos *v1, Alunos *v2)
{
    Alunos aux = *v1;
    *v1 = *v2;
    *v2 = aux;
}

void Imprimir( Alunos *v, int n)
{
    int i;
    
    for(i = 0; i < n; i++)
    {
        printf("%d ", v[i].chave);
    }
    printf("\n");
}


