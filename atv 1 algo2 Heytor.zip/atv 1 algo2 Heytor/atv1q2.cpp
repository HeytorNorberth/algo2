#include<Stdio.h>
int main(){
float SB, SL, INSS; 
printf ("Digite o Salario Bruto: "); 
scanf("%f", &SB); 
if(SB<=600)
{ printf("Sem alteracao: R$ %.2f", SB);

}else if(SB>600 && SB<=1200){ INSS=(SB*20)/100; SL= SB - INSS;  
printf("Desconto de 20 por cento:  \nR$%.2f \nR$ %.2f", INSS,SL);

}else if(SB>1200 && SB<=2000){ INSS=(SB*25)/100; SL= SB - INSS; 
 printf("Desconto de 25 por cento:  \nR$%.2f \n% R$.2f",INSS, SL);

}else{ INSS=(SB*30)/100; SL= SB - INSS; 
 printf("Desconto de 30 por cento:  \nR$%.2f \nR$%.2f",INSS, SL); } return 0;}

