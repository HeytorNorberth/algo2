#include <stdio.h>
int main(){

int i;
char p[20];
printf("Digite uma palavra:");
gets(p);
	for(i=0;i<20;i++){
	if(p[i]=='r'){
		printf("l");
	}else{
		printf("%c",p[i]);
	}
}
return 0;

}
