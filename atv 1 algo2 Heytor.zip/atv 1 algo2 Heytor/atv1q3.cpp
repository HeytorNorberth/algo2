#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

 int main (){
   
    int i,vgm;
    char a=97,b=98,c=99,d=100,dest;
   
    for(i=1;i<=20;i++)
    putchar('*');
    putchar('\n');
    printf("\nDESTINO:\n\n a- Regiao Norte\n b- Regiao Nordeste\n c- Regiao Centro Oeste\n d- Regiao Sul\n\n");
    for(i=1;i<=20;i++)
    putchar('*');
    putchar('\n');
    printf("\nInforme seu Destino:  ");
    scanf("%c",&dest);
    printf("\nViagem de:\n\n 0- Ida\n 1- Ida e Volta\n\n ");
    scanf("%d",&vgm);

    if((dest==97)&&(vgm==0)){
    printf("\nDESTINO: Regiao Norte\n");
    printf("\n500.00 reais - IDA\n");
}
    else if ((dest==97)&&(vgm==1)){
    printf("\nDESTINO: Regiao Norte\n");
    printf("\n900.00 reais - IDA e VOLTA\n");
}
   else if((dest==98)&&(vgm==0)){
        printf("\nDESTINO: Regiao Nordeste\n");
        printf("\n350.00 reais - IDA\n");
    }
    else if ((dest==98)&&(vgm==1)){
        printf("\nDESTINO: Regiao Nordeste\n");
        printf("\n650.00 reais - IDA e VOLTA\n");
    }
     else if((dest==99)&&(vgm==0)){
        printf("\nDESTINO: Regiao Centro Oeste\n");
        printf("\n350.00 reais - IDA\n");
    }
    else if ((dest==99)&&(vgm==1)){
        printf("\nDESTINO: Regiao Centro Oeste\n");
        printf("\n600.00 reais - IDA e VOLTA\n");
    }
    else if((dest==100)&&(vgm==0)){
        printf("\nDESTINO: Regiao Sul\n");
        printf("\n300.00 reais - IDA\n");
    }
    else if((dest==100)&&(vgm==1)){
        printf("\nDESTINO: Regiao Sul\n");
        printf("\n550.00 reais - IDA e VOLTA\n");
    }
    getch();
}
