#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
int main(void)
{
    int i, maiusculo;
    char Sptr[30];
    while(1){
    scanf("%s", Sptr);
    maiusculo = strlen(Sptr);
    for(i=0; i<maiusculo; i++)
    {                            // Converte cada caracter de Sptr
     Sptr[i] = toupper (Sptr[i]);  // para maiusculas
    }
    printf("%s",Sptr);
	}
    getch();
    return 0;
}
