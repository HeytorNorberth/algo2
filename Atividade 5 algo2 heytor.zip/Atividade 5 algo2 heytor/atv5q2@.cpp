#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int raizes(float a, float b, float c, float *x1, float *x2) {
    float delta;
    int numeroRaizes;
    delta = (b*b) - (4*a*c);
    if (delta < 0) {
       numeroRaizes = 0;
    } else if (delta == 0) {
           numeroRaizes = 1;
           *x1 = -b/(2*a);
           *x2 = *x1;
    } else {
            numeroRaizes = 2;      
            *x1 = (-b - sqrt(delta))/(2*a);
            *x2 = (-b + sqrt(delta))/(2*a);
    }
    return numeroRaizes;
}
int main() {
    float a, b, c,raiz1,raiz2;
    int numeroRaizes;
    while(1){
    printf("Por favor, digite os coeficientes a,b,c\n");
    scanf("%f%f%f",&a,&b,&c);
    numeroRaizes = raizes(a,b,c,&raiz1,&raiz2);
    if (numeroRaizes==0 ) {
       printf("\ncomplexo\n");
    } else {
       printf("\nAs raizes sao %f e %f\n",raiz1, raiz2);
    }
    if(numeroRaizes==0){
    	printf("Fim do programa");
    	break;
	}
	
	}
    system("PAUSE");
    return 0;

}

