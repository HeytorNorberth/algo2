#include <stdio.h>

int main(){
    int n = 0, i, f[11];

    for(i = 0; i < 11; i++){
        f[i] = 0;

    }

    while(n > -1 && n <= 10){
        scanf("%d", &n);
        f[n]++;

    }

    for(i = 0; i < 11; i++){
        printf("%d %d\n", i, f[i]);

    }

    return 0;
}
