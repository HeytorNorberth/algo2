#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <locale.h>

typedef struct 
{
    char valor[10], naipe[10];
    int validar;
} card;

void CopiarCartas(char*, char*);

void CartasAleatorias(card*);

void CartasOrdenadas(card*);


int main(void)
{
    setlocale(LC_ALL, "portuguese");
    srand(time(NULL));
    
    card deck[52] = {};
    
    int n, i;
    scanf("%d", &n);
    if(n == 1)
    {
        CartasOrdenadas(deck);
        for(i = 0; i < 52; i++)
            printf("%s de %s\n", deck[i].valor, deck[i].naipe);
    }
    if(n == 0)
    {
        CartasAleatorias(deck);
        for (i = 0; i < 52; i++)
            printf("%s de %s\n", deck[i].valor, deck[i].naipe);
    }
    return 0;
}

void CartasOrdenadas(card* deck) 
{
    char valor[][10] = {"Ás", "Dois", "Três", "Quatro",
                         "Cinco", "Seis", "Sete", "Oito",
                         "Nove", "Dez", "Valete", "Dama", "Rei"},
         naipe[][10] = {"Paus", "Ouros", "Copas", "Espadas"};
        
    int i, j, n = 0;
    for(i = 0; i < 4; i++)
    {
        for(j = 0; j < 13; j++, n++){
            CopiarCartas(deck[n].valor, valor[j]);
            CopiarCartas(deck[n].naipe, naipe[i]);
        }
    }
    
 
}

void CartasAleatorias(card* deck)
{
    char valor[][10] = {"Ás", "Dois", "Três", "Quatro",
                         "Cinco", "Seis", "Sete", "Oito",
                         "Nove", "Dez", "Valete", "Dama", "Rei"},
         naipe[][10] = {"Paus", "Ouros", "Copas", "Espadas"};

    int i, j;
    for (i = 0; i < 4; i++)
        for (j = 0; j < 13; 1)
        {
            int index = rand() % 52;
            if (deck[index].validar != 0)
                continue;
            
            CopiarCartas(deck[index].valor, valor[j++]);
            CopiarCartas(deck[index].naipe, naipe[i]);
            deck[index].validar = 1;
        }
}

void CopiarCartas(char* str1, char* str2)
{
    int i;
    for (i = 0; str2[i] != 0; i++)
        str1[i] = str2[i];
}