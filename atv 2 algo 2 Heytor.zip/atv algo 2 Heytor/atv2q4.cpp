#include <stdio.h>
#include <stdlib.h>


int main() {
    
    int i, n[10]={0}, j, count, copia[10]={0};
    
    
    for(i=0;i<10;i++){
        printf("Numero: ");
        scanf("%d", &n[i]);
        
        while(count!=-1){
            
            for(j=1;j<=10;j++){
                if(n[i]==n[i-1]){
                    count=-1;
                }
            }
            if(count!=-1){
                printf("N: %d\n", n[i]);
            }
            count=-1;
        }
        count=0;
        
    }

    
    return 0;
}
