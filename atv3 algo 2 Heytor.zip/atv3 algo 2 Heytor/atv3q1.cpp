#include <stdio.h>
int main() {

    long nUm, inverso = 0, manter, lembrar;

    printf( "Digite um n\243mero:\n" );
    scanf( "%ld", &nUm );
    manter = nUm;

    for ( ; nUm > 0; ) {

        lembrar = nUm % 10;
        inverso = inverso * 10 + lembrar;
        nUm /= 10;
    }

    printf( "N\243mero digitado = %ld\n", manter );
    printf( "N\243mero inverso = %ld\n", inverso );

    return 0;
}
