#include <stdio.h>

int main()
{
        int lado1,lado2,count=1;

        printf("Lados do quadrado: ");
        scanf("%d%d", &lado1,&lado2);

        //Imprimindo a primeira linha
        while(count<=lado2)
        {
            printf("*");
            count++;
        }
        printf("\n");

        count=1;
        while( count <= lado1*(lado1-2))
        {
            if( (count%lado1 == 1))
                printf("*");
            else
                if( (count%lado1 == 0))
                    printf(" *\n");
                else
                    printf(" ");

            count++;
        }

        //Imprimindo a primeira linha
        count=1;
        while(count<=lado2)
        {
            printf("*");
            count++;
        }
        printf("\n");


}
