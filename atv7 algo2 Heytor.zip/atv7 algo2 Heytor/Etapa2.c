#include <stdio.h>
#include <time.h>
#include <stdlib.h>

typedef struct 
{
    int chave;
    char nome[30], endereco[50], telefone[14];
} Alunos;

void gerarDados(Alunos *v, int n, int ordemChave);

void troca (Alunos *v1, Alunos *v2);

void Imprimir(Alunos *v, int n);

void bolha(Alunos *v, int n);

void selecao(Alunos *v, int n);

void insercao(Alunos *v, int n);

int main()
{
    srand(time(NULL));
    
    int n, i, ordem, metodo;
    
    scanf("%d", &n);
    
    while(1)
    {
        scanf("%d", &ordem);
        
        if(ordem == 3) break;
        scanf("%d", &metodo);
        
        if(metodo == 0) printf("bolha\n");
        else if(metodo == 1) printf("selecao\n");
        else if(metodo == 2) printf("insercao\n");
        
        Alunos vetor[n];
         
        gerarDados(vetor, n, ordem);
        Imprimir(vetor, n);
        
        if (metodo == 0)
        {
            bolha(vetor, n);
        }
        else if (metodo == 1){
            selecao(vetor, n);
        }
        else if (metodo == 2){
            insercao(vetor, n);
        }
        Imprimir(vetor, n);
    }
   
    return 0;
}

void bolha(Alunos *v, int n)
{
    int i, j;
    for (i = 0; i < n-1; i++){
        for (j = 1; j < n-i; j++)
            if (v[j].chave < v[j-1].chave)
                troca(&v[j], &v[j-1]);
    }
}

void selecao(Alunos *v, int n)
{
    int i, j, min;
    for (i = 0; i < n-1; i++)
    {
        min = i;
        for (j = i+1; j < n; j++)
            if (v[j].chave < v[min].chave)
                min = j;
        troca(&v[i], &v[min]);
    }
}

void insercao(Alunos *v, int n)
{
    int i, j;
    Alunos aux;
    for (i = 1; i < n; i++)
    {
        aux = v[i];
        j = i-1;
        while ((j >= 0) && (aux.chave < v[j].chave))
        {
            v[j+1] = v[j];
            j--;
        }
        v[j+1] = aux;
    }
}

void gerarDados(Alunos *v, int n, int ordemChave)
{
    int i, index;
    
    if(ordemChave == 0 || ordemChave == 1)
    {
        for(i = 0; i < n; i++)
        {
            v[i].chave = i+1;
        }
    }
    else if(ordemChave == 2)
    {
        int j;
        for(i = n-1, j = 0; i >= 0; i--, j++){
            v[j].chave = i+1;
        }
    }
    if(ordemChave == 1)
    {
        int j;
        for(i = 0, j = n*n; j > 0; i++, j--)
        {
            if(i = n)
            {
                i = 0;
                index = rand() % n;
                troca(&v[i], &v[index]);
            }
        }
    }
}

void troca(Alunos *v1, Alunos *v2)
{
    Alunos aux = *v1;
    *v1 = *v2;
    *v2 = aux;
}

void Imprimir( Alunos *v, int n)
{
    int i;
    
    for(i = 0; i < n; i++)
    {
        printf("%d ", v[i].chave);
    }
    printf("\n");
}
