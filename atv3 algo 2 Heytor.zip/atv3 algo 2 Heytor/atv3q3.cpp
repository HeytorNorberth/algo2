#include<stdio.h>
#include<conio.h>
#include<stdlib.h> 
#include<time.h>
#include<string.h>
#include<math.h>


main ()

{
        int i,x, cara=0, coroa=0;
        srand(time(NULL));
        
        printf("cara=1\ncoroa=0\n", RAND_MAX);
        
           for (i = 1; i <= 100; i++)
{
    x = rand() % 2;

    printf("Jogada %d: %d\n", i , x);

    if (x == 1)
    {
        coroa += 1;
    }
    else
    {
        cara += 1;
    }
}

printf("Cara: %d, Coroa: %d\n", cara, coroa);
 return 0;
 
 }
