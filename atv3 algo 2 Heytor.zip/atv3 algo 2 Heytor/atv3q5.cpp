#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <stdlib.h>

int random();
void dicas(int number, int password, int attempt);
int main()
{
int continuar = 1, password, attempt, number;
do
{
printf("*************** Eu tenho um numero entre 1 e 1000.Voce pode adivinhar meu numero?...\n\n");
password = random();

printf("*************** Comecou, tente adivinhar o numero e boa sorte!...\n\n");
attempt = 0;

do
{
attempt++;
printf("Tentativa %d\n", attempt);
scanf("%d", &number);

dicas(number, password, attempt);
}
while(number != password);
printf("Digite 0 para sair. ");
scanf("%d", &continuar);
}
while(continuar);
}

int random()
{
srand((unsigned) time(NULL));
return (1 + rand()% 1000);
}
void dicas(int number, int password, int attempt)
{
if(number > password)
printf("Muito alto. Tente novamente. %d\n\n", number);

else
if (number < password)
printf("Muito baixo. Tente novamente. %d\n\n", number);

else
printf("Excelente! Voce adivinhou o numero em: %d tentativas.\n\n", attempt);
}
