#include<stdio.h> 
int main(){
	int v[10],i,j;
	printf("digite os numeros: \n");
	for(i=0;i<10;i++){
		scanf("%d",&v[i]);
	}

	for(i=0;i<10;i++){
		printf(" \n ",i);
	for(j=0;j<v[i];j++) {
		printf("*");
		}
	printf("\n");
	}
}
