#include <stdio.h>
void cubo(int *nPtr){ 
(*nPtr)=(*nPtr)*(*nPtr)*(*nPtr);	
}
int main(){
int numero;
 while(1)
 {
  printf("Digite um numero: ");
  scanf("%d", &numero);
  cubo(&numero);
  if (numero==0){
  	printf("Fim do progrma");
  break;
  }
  printf("\n\nValor ao cubo: %i\n\n",numero);
  }
  return 0;
  }
  
  	

