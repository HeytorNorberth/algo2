#include <stdio.h>
int main(){
  int pares[10]={2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
  int i;
  printf("%s%13s\n","Elemento", "Valor");
  for(i=0; i<=9; i++){
    printf("%7d%13d\n", i,pares[i]);
  }
  return 0;
}
