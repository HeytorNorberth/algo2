#include <stdio.h>
#include <math.h>

struct p_cartesiano{
    float x1, x2;
    float y1, y2;
}; 
   
int main()
{
    struct p_cartesiano ponto;
    printf("Digite as cordenadas: ");
    scanf("%f %f", &ponto.x1, &ponto.x2);
    scanf("%f %f", &ponto.y1, &ponto.y2);
    
    float d = sqrt(pow(ponto.x1 - ponto.y1, 2) + pow(ponto.x2 - ponto.y2, 2));
    printf("Distancia: %.4f\n", d);
    return 0;
}
