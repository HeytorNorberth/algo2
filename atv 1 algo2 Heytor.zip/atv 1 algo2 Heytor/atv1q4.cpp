#include <stdio.h>

int main(){

    float q;

    printf("Entre com o PRECO DE COMPRA.\n");
    scanf("%f",&q);

    if(q <12){

        printf("VALOR DE VENDA : %.2f\n", q * 1.30);

    }else{
        printf("VALOR DE VENDA : %.2f\n", q * 1.0);
    }


    return(0);
}
