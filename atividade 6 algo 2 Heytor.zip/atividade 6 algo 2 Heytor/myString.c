#include <stdio.h>
#include "myString.h"

char *strcpy(char *g1, const char *g2){
	int i=0;
	while(g2[i] != '\0'){
		g1[i]=g2[i];
		i++;
	}
	return g1;
}
char *strncpy(char *g1, const char *g2, int n){
	int i=0;
	while(n > 0){
		g1[i]=g2[i];
		i++;
		n--;
	}
	return g1;
}
char *strcat(char *g1, const char *g2){
	int i=0, n;
	while(g1[i] != '\0'){
		i++;
	}
	n=i;
	i=0;
	while(g2[i] != '\0'){
		g1[n]=g2[i];
		n++;
		i++;
	}
	return g1;		
}
char *strncat(char *g1, const char *g2, int n){
	int i;
	for(i=0; i<=n-1; i++){
		g1[i]=g2[i];
	}
	return g1;
}
char *strcmp(char *g1, const char *g2){
	int i, n=0;
	for(i=0; g1[i]||g2[i] != '\0'; i++){
		if(g1[i]>g2[i]){
			return 1;
		}
		else if(g2[i]>g1[i]){
			return -1;
		}
		else if(g2[i]==g1[i]){
			n=0;
		}
	}
	if(n==0){
		return 0;
	}
		
}
char *strncmp(char *g1, const char *g2, int h){
	int i, n;
	for(i=0; i<h; i++){
		if(g2[i]==g1[i]){
			n=0;
		}
		else if(g1[i]>g2[i]){
			n--;
		}
		else if(g2[i]>g1[i]){
			n++;
		}
	}
	if(n==0){
		return 0;
	}
	else if(n>0){
		return -1;
	}
	else if(n<0){
		return 1;
	}	
}
