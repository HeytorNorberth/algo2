#include <stdio.h>

typedef struct {
    char nome[20];
    float altura, peso, ira;
} Info;
typedef struct 
{
    int index[3];
    float media[3];
} res;

res retornaTudo(Info*);
void print(res, Info*);

int main()
{
    Info Dados[5] = {};
    
    int i;
    for(i = 0; i < 5; i++)//pega dados
    scanf("%s %f %f %f",  Dados[i].nome, &Dados[i].altura, &Dados[i].peso,&Dados[i].ira);
    
    print(retornaTudo(Dados), Dados);

    return 0;
}
res retornaTudo(Info* alunos)
{
    res retornaTudo = {{}, {alunos[0].peso,alunos[0].altura,alunos[0].ira}};
    int i;
    for (i = 1; i < 5; i++)
    {
    retornaTudo.media[0] += alunos[i].peso;
    retornaTudo.media[1] += alunos[i].altura;
    retornaTudo.media[2] += alunos[i].ira;

    if (alunos[i].peso > alunos[retornaTudo.index[0]].peso)
            retornaTudo.index[0] = i;
    if (alunos[i].altura > alunos[retornaTudo.index[1]].altura)
            retornaTudo.index[1] = i;
    if (alunos[i].ira > alunos[retornaTudo.index[2]].ira)
            retornaTudo.index[2] = i;
    }

    retornaTudo.media[0] /= 5;
    retornaTudo.media[1] /= 5;
    retornaTudo.media[2] /= 5;

    return retornaTudo;
}
void print(res result, Info* alunos)
{
    printf("Media de Peso: %.3f\n", result.media[0]);
    printf("Media de Altura: %.3f\n", result.media[1]);
    printf("Media de IRA: %.3f\n\n", result.media[2]);
    printf("Maior Peso: %s (%.3f)\n", alunos[result.index[0]].nome, alunos[result.index[0]].peso);
    printf("Maior Altura: %s (%.3f)\n", alunos[result.index[1]].nome, alunos[result.index[1]].altura);
    printf("Maior IRA: %s (%.3f)\n\n", alunos[result.index[2]].nome, alunos[result.index[2]].ira);
}
