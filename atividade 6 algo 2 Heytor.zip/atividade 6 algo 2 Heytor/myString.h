char *strcpy(char *g1, const char *g2);

char *strncpy(char *g1, const char *g2, int n);

char *strcat(char *g1, const char *g2);

char *strncat(char *g1, const char *g2, int h);

int *strcmp( char *g1, const char *g2);

int *strncmp( char *g1, const char *g2, int h);
