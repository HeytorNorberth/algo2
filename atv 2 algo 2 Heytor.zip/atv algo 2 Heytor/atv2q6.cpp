#include <stdio.h>
#define m 4
#define n 6
#define p 5


int main(){
    int A[m][n], B[n][p], C[m][p];
    int i, j, b, z;

    printf("Insira a primeira matriz: \n");
    for(i = 0; i < m; i++){
        for(j = 0; j < n; j++){
            scanf("%d", &A[i][j]);
        }
    }

    printf("Insira a segunda matriz: \n");
    for(i = 0; i < n; i++){
        for(j = 0; j < p; j++){
            scanf("%d", &B[i][j]);
        }
    }

    for(i = 0; i < m; i++){
        for(j = 0; j < p; j++){
            C[i][j] = 0;
        }
    }

    printf("Produto das matrizes: \n");
    for(i = 0; i < m; i++){
        for(j = 0; j < p; j++){
            for(b = 0; b < n; b++){
                C[i][j] += A[i][b]*B[b][j];
            }

            printf("%d ", C[i][j]);
        }

        printf("\n");

    }

    return 0;

}
