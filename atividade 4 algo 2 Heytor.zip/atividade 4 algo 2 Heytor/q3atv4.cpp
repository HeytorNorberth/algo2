#include<stdio.h>
#include<time.h>
#include<string.h>
#define TAM1 4
#define TAM2 13
#define TAM3 52

void embaralha(int localbaralho[][TAM2], int );
void impressao(int localbaralho2[][TAM2], int ,char *face2[TAM2],char *naipe2[TAM1]);
void distribui(int localbaralho3[][TAM2], int ,char *face3[TAM2],char *naipe3[TAM1]);

int main(){
	char *naipe[TAM1]={"Paus","Ouros","Copas","Espadas"},
	     *face[TAM2]={"As","Dois","Tres","Quatro","Cinco","Seis","Sete","Oito", "Nove","Dez","Valete","Dama","Rei"};
	int baralho[TAM1][TAM2]={0};			
	srand(time(NULL));

	impressao(baralho,TAM2,face,naipe);	
	embaralha(baralho,TAM2);
	
	return 0;	
}

void embaralha(int localbaralho[][TAM2], int tamanho){            
	int linha,coluna,carta;
	for(carta=1;carta<=TAM3-1;carta++){
		linha=rand()%4;
		coluna=rand()%13;
		while(localbaralho[linha][coluna]!=0){
			linha=rand()%4;
			coluna=rand()%13;			
		}
		localbaralho[linha][coluna]=carta;
	}
}

void distribui(int localbaralho3[][TAM2],int tamanho2,char *face3[TAM2],char *naipe3[TAM1]){   
	int linha, coluna, carta;
	for(carta=1;carta<=TAM3-1;carta++){
		for(coluna=0; coluna<=TAM2-1;coluna++){
			for(linha=0; linha<=TAM1-1; linha++){				
				if(localbaralho3[coluna][linha]==carta){						
					printf("%s de %s\n",face3[coluna],naipe3[linha]);
				}
			}
		}
	}
}

void impressao(int localbaralho2[][TAM2],int tamanho,char *face2[TAM2],char *naipe2[TAM1]){   																										   //ordenado -primeira impressao
	int linha,coluna;
	printf("\n\n");
	for(coluna=0;coluna<=TAM2-1;coluna++){
		for(linha=0;linha<=TAM1-1;linha++){
			printf("%s de %s\n", face2[coluna], naipe2[linha]);
		}
	}
	printf("\n");
}
