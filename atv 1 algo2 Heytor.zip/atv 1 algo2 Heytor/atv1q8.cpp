#include <stdio.h>

int main()
{
        int lado1,lado2,count=1;

        printf("Lados do quadrado: ");
        scanf("%d%d", &lado1,&lado2);

        while( count <= lado2*lado1)
        {
            if(count % lado2 == 0)
                printf("*\n");
            else
                printf("*");

            count++;
        }
        
		}
