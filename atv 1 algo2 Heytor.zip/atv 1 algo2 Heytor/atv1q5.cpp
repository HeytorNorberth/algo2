#include <stdio.h>

int main() {

int h1, h2, m1, m2, mais_velho, mais_nova, soma_idade,mais_novo,mais_velha,soma_idade2;

printf("Informe a idade do 1� homem: ");

scanf("%d", &h1);

do {

printf("Informe a idade do 2� homem (diferente do primeiro): ");

scanf("%d", &h2);

} while (h1==h2);

printf("Informe a idade da 1� mulher: ");

scanf ("%d", &m1);

do {

printf("Informe a idade da 2� mulher (diferente da primeira): ");

scanf("%d", &m2);

} while (m1==m2);

if (h1>h2)

mais_velho=h1;

else

mais_velho=h2;

if (m1<m2)

mais_nova=m1;

else

mais_nova=m2;

if (h1<h2)

mais_novo=h1;

else

mais_novo=h2;

if (m1>m2)

mais_velha=m1;

else

mais_velha=m2;

soma_idade2=mais_novo+mais_velha;

soma_idade=mais_velho+mais_nova;

printf("\nA soma das idades do homem mais velho com a muher mais nova e: %d\n", soma_idade);
printf("\nA soma das idades homem mais novo com a mulher mais velha e: %d\n",soma_idade2);

return 0;

}



