#include <stdio.h>

float numero_real[3];
float numero_imaginario[3];
int opcao, i;
float res_real, res_imaginario;

int menu(void)
{
     
     printf ("Deseja fazer alguma operacao?[1]Abrir [0]Sair");
     scanf ("%d", &opcao);
     return opcao;
}

void soma_numero()
{
    float listanumero3;

    res_real = numero_real[1] + numero_real[2];
    res_imaginario = numero_imaginario[1] + numero_imaginario[2];
    printf ("\n%4.2f + %4.2fi\n", res_real, res_imaginario);
    
}

int main ()
{  
while(1){
          menu();
          switch (opcao)
          {
                 case 1:
                      for (i = 1; i <= 2;i++)
                      {
                          printf("\nDigite o numero complexo, informando primeiro a parte REAL e depois a parte IMAGINARIA\n");
                          scanf ("%f %f", &numero_real[i], &numero_imaginario[i]);
                      }
                      soma_numero();
                      break;
                 case 0:
                      return 0;
          }




}
}

